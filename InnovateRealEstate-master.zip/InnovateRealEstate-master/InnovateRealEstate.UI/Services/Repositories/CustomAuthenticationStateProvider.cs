﻿using Microsoft.AspNetCore.Components.Authorization;
using Blazored.LocalStorage;
using System.Security.Claims;

namespace InnovateRealEstate.UI.Services.Repositories
{
    public class CustomAuthenticationStateProvider : AuthenticationStateProvider
    {
        private readonly ILocalStorageService _localStorageService;
        private const string TokenKey = "authToken";
        private readonly AuthenticationState _anonymous = new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
        private ClaimsPrincipal _currentUser = new ClaimsPrincipal(new ClaimsIdentity());

        public CustomAuthenticationStateProvider(ILocalStorageService localStorageService)
        {
            _localStorageService = localStorageService;
        }

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            // You can return a default value initially, the real data will be fetched in OnAfterRenderAsync
            var token = await _localStorageService.GetItemAsync<string>(TokenKey);
            var identity = string.IsNullOrEmpty(token)? new ClaimsIdentity(): new ClaimsIdentity(ParseClaimsFromJwt(token),"jwt");
            _currentUser = new ClaimsPrincipal(identity);
            return new AuthenticationState(_currentUser);
        }

        public async Task MarkUserAsAuthenticated(string token)
        {
            await _localStorageService.SetItemAsync(TokenKey, token);

            var claims = ParseClaimsFromJwt(token);
            var identity = new ClaimsIdentity(claims, "jwt");
            var user = new ClaimsPrincipal(identity);

            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(user)));
        }

        public async Task MarkUserAsLoggedOut()
        {
            await _localStorageService.RemoveItemAsync(TokenKey);

            NotifyAuthenticationStateChanged(Task.FromResult(_anonymous));
        }

        private IEnumerable<Claim> ParseClaimsFromJwt(string jwt)
        {
            var payload = jwt.Split('.')[1];
            var jsonBytes = DecodeBase64(payload);
            var keyValuePairs = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(jsonBytes);

            return keyValuePairs?.Select(kvp => new Claim(kvp.Key, kvp.Value?.ToString() ?? string.Empty))
                   ?? Enumerable.Empty<Claim>();
        }

        private byte[] DecodeBase64(string base64)
        {
            base64 = base64.Replace('-', '+').Replace('_', '/');
            switch (base64.Length % 4)
            {
                case 2: base64 += "=="; break;
                case 3: base64 += "="; break;
            }
            return Convert.FromBase64String(base64);
        }

        // Using OnAfterRenderAsync to get the token after the component has rendered
        //public async Task LoadAuthenticationStateAsync()
        //{
        //    var token = await _localStorageService.GetItemAsync<string>(TokenKey);

        //    if (string.IsNullOrEmpty(token))
        //    {
        //        _currentUser = new ClaimsPrincipal(new ClaimsIdentity());
        //    }
        //    else
        //    {
        //        try
        //        {
        //            var claims = ParseClaimsFromJwt(token);
        //            var identity = new ClaimsIdentity(claims, "jwt");
        //            _currentUser = new ClaimsPrincipal(identity);
        //        }
        //        catch
        //        {
        //            // Handle invalid token scenario
        //            _currentUser = new ClaimsPrincipal(new ClaimsIdentity());
        //            await _localStorageService.RemoveItemAsync(TokenKey);
        //        }
        //    }

        //    NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(_currentUser)));
        //}
    }
}
