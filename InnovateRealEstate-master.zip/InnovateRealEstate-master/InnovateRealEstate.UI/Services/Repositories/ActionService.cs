﻿using InnovateRealEstate.UI.Services.Interfaces;
using System.Net.Http;

namespace InnovateRealEstate.UI.Services.Repositories
{
    public class ActionService : IActionService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public HttpClient httpClient { get; set; }
        public ActionService(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
             httpClient = _httpClientFactory.CreateClient("API");
        }
        public async Task<T?> GetData<T>(string url)
        {

           var response = await httpClient.GetAsync(url);
            var result = await response.Content.ReadFromJsonAsync<T>();
            return result;
        }

        public async Task<T?> GetFileData<T>(string url)
        {
            var response = await httpClient.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var contentType = response.Content.Headers.ContentType?.MediaType;

                if (contentType == "application/json")
                {
                    return await response.Content.ReadFromJsonAsync<T>();
                }
                else if (typeof(T) == typeof(string))
                {
                    var rawString = await response.Content.ReadAsStringAsync();
                    return (T)(object)rawString; // Cast the string to T
                }
            }
            return default;
        }


        public Task<T> GetSingleRecord<T>(int Id, string url)
        {
            throw new NotImplementedException();
        }

        public async Task<T?> SaveData<T, D>(string url, D data)
        {
            var response = await httpClient.PostAsJsonAsync(url, data);
            var result = await response.Content.ReadFromJsonAsync<T>();

            return result;
        }

        public async Task<T?> FileHandler<T>(string url, Object formFile)
        {
            var response = await httpClient.PostAsync(url, (HttpContent?)formFile);
            var result = await response.Content.ReadFromJsonAsync<T>();

            return result;
        }
    }
}
