﻿namespace InnovateRealEstate.UI.Services.Interfaces
{
    public interface IActionService
    {
        Task<T?> SaveData<T, D>(string url, D data);
        Task<T?> GetData<T>(string url);
        Task<T> GetSingleRecord<T>(int Id, string url);
        Task<T?> FileHandler<T>(string url, Object formFile);
        Task<T?> GetFileData<T>(string url);
    }
}
