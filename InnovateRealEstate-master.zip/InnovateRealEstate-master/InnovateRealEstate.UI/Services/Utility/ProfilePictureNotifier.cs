﻿namespace InnovateRealEstate.UI.Services.Utility
{
    public class ProfilePictureNotifier
    {
        public string? UpdatedProfilePictureUrl { get; private set; }

        public event Action? OnProfilePictureUpdated;

        public void NotifyProfilePictureUpdated(string newProfilePictureUrl)
        {
            UpdatedProfilePictureUrl = newProfilePictureUrl;
            OnProfilePictureUpdated?.Invoke();
        }
    }
}
