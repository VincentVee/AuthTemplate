﻿using System.Security.Claims;

namespace InnovateRealEstate.UI.Services.Utility
{
    public static class ClaimsPrincipalExtensions
    {
        public static string GetUserId(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Replace with the claim type used for the User ID in your system
            return principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value ?? "Unknown User ID";
        }

        public static string GetFirstName(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Replace with the claim type used for First Name in your system
            return principal.Claims.FirstOrDefault(c => c.Type == "FirstName")?.Value ?? "Unknown First Name";
        }

        public static string GetLastName(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Replace with the claim type used for Last Name in your system
            return principal.Claims.FirstOrDefault(c => c.Type == "LastName")?.Value ?? "Unknown Last Name";
        }

        public static string GetUserRole(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Retrieve the Role claim
            return principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "No Role";
        }

        public static string GetUserEmail(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Retrieve the Role claim
            return principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? "No Email";
        }

        public static string GetUserName(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Retrieve the Role claim
            return principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value ?? "Unknown Username";
        }

        public static string GetUserPhoneNumber(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            // Retrieve the Role claim
            return principal.Claims.FirstOrDefault(c => c.Type == "PhoneNumber")?.Value ?? "Unknown Phone Number";
        }
    }
}
