﻿using MudBlazor;

namespace InnovateRealEstate.UI.Services.Utility
{
    public interface ILayoutService
    {
        MudTheme CurrentTheme { get; }
        bool IsDarkMode { get; }
        bool IsLoading { get; }

        event EventHandler MajorUpdateOccurred;

        Task ApplyUserPreferences(bool isDarkModeDefaultTheme);
        void SetBaseTheme(MudTheme theme);
        void SetDarkMode(bool value);
        void SetLoading(bool value);
        //string GetSchoolName();
        Task ToggleDarkMode();
    }
}
