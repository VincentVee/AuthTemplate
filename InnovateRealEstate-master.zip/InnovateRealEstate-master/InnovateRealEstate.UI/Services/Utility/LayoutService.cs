﻿using Blazored.LocalStorage;
using MudBlazor;

namespace InnovateRealEstate.UI.Services.Utility
{
    public class LayoutService(IUserPreferencesService userPreferencesService) : ILayoutService
    {
        public bool IsDarkMode { get; private set; } = false;
        public MudTheme CurrentTheme { get; private set; }
        private readonly IUserPreferencesService _userPreferencesService = userPreferencesService;
        private UserPreferences _userPreferences;
        bool isLoading;
        public void SetDarkMode(bool value)
        {
            IsDarkMode = value;
        }

        public async Task ApplyUserPreferences(bool isDarkModeDefaultTheme)
        {
            _userPreferences = await _userPreferencesService.LoadUserPreferences();
            if (_userPreferences != null)
            {
                IsDarkMode = _userPreferences.DarkTheme;

            }
            else
            {
                IsDarkMode = isDarkModeDefaultTheme;
                _userPreferences = new UserPreferences { DarkTheme = IsDarkMode };
                await _userPreferencesService.SaveUserPreferences(_userPreferences);
            }
        }

        public event EventHandler MajorUpdateOccurred;

        private void OnMajorUpdateOccurred() => MajorUpdateOccurred?.Invoke(this, EventArgs.Empty);

        public async Task ToggleDarkMode()
        {
            _userPreferences = await _userPreferencesService.LoadUserPreferences();
            if (_userPreferences != null)
            {
                IsDarkMode = _userPreferences.DarkTheme;

            }
            else
            {
                IsDarkMode = false;
                _userPreferences = new UserPreferences { DarkTheme = IsDarkMode };
                await _userPreferencesService.SaveUserPreferences(_userPreferences);
            }

            IsDarkMode = !IsDarkMode;
            _userPreferences.DarkTheme = IsDarkMode;
            await _userPreferencesService.SaveUserPreferences(_userPreferences);
            OnMajorUpdateOccurred();
        }
        public bool IsLoading { get => isLoading; }

        public void SetBaseTheme(MudTheme theme)
        {
            CurrentTheme = theme;
            OnMajorUpdateOccurred();
        }

        public void SetLoading(bool value)
        {
            isLoading = value;
        }
    }
    public class UserPreferences
    {
        /// <summary>
        /// If true DarkTheme is used. LightTheme otherwise
        /// </summary>
        public bool DarkTheme { get; set; }
    }
    public interface IUserPreferencesService
    {
        /// <summary>
        /// Saves UserPreferences in local storage
        /// </summary>
        /// <param name="userPreferences">The userPreferences to save in the local storage</param>
        public Task SaveUserPreferences(UserPreferences userPreferences);

        /// <summary>
        /// Loads UserPreferences in local storage
        /// </summary>
        /// <returns>UserPreferences object. Null when no settings were found.</returns>
        public Task<UserPreferences> LoadUserPreferences();
    }

    public class UserPreferencesService(ILocalStorageService localStorage) : IUserPreferencesService
    {
        private readonly ILocalStorageService _localStorage = localStorage;
        private const string Key = "userPreferences";

        public async Task SaveUserPreferences(UserPreferences userPreferences)
        {
            await _localStorage.SetItemAsync(Key, userPreferences);
        }

        public async Task<UserPreferences> LoadUserPreferences()
        {
            return await _localStorage.GetItemAsync<UserPreferences>(Key);
        }
    }
}
