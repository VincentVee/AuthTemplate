﻿using MudBlazor;
using System.ComponentModel;

namespace InnovateRealEstate.UI.Services.Utility
{
    internal class BreadcrumbHelper
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private readonly List<BreadcrumbItem> _breadcrumbsList = [];

        public List<BreadcrumbItem> BreadcrumbsList => _breadcrumbsList;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public void UpdateBreadcrumbs(IEnumerable<BreadcrumbItem> breadcrumbs)
        {
            _breadcrumbsList.Clear();
            _breadcrumbsList.AddRange(breadcrumbs);
            UpdateBreadcrumbsList();
        }
        private void UpdateBreadcrumbsList()
        {
            OnPropertyChanged(nameof(BreadcrumbsList));
        }
    }
}
