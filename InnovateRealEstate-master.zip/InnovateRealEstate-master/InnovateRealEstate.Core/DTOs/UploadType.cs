﻿namespace InnovateRealEstate.Core.DTOs
{
    public enum UploadType {ProdilePicture, Listing};
   
}
