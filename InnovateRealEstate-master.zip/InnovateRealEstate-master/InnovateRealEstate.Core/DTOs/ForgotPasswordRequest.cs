﻿using System.ComponentModel.DataAnnotations;

namespace InnovateRealEstate.Core.DTOs
{
    public class ForgotPasswordRequest
    {
        [Required(ErrorMessage = "Emails Address is required!")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        public string ClientUrl { get; set; }
    }
}
