﻿using System.ComponentModel.DataAnnotations;

namespace InnovateRealEstate.Core.DTOs
{
    public class ResetPasswordRequest
    {
        public string Token { get; set; }

        [Required(ErrorMessage = "New Password is required!")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Password Confirmation is required!")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "New Password and Password Confirmation do not match")]
        public string ConfirmNewPassword { get; set; }
        public string Email { get; set; }
    }
}
