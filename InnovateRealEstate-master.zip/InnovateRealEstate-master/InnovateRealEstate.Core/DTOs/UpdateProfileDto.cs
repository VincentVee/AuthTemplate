﻿using System.ComponentModel.DataAnnotations;

namespace InnovateRealEstate.Core.DTOs
{
    public class UpdateProfileDto
    {
        public string UsertId { get; set; }
        [Required(ErrorMessage = "Username is required")]
        [DataType(DataType.Text, ErrorMessage = "Please enter the correct username")]
        public string UserName { get; set; }
        public string ProfilePicUrl { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [DataType(DataType.Text, ErrorMessage = "Please enter the correct first name")]
        public string FirstName { get; set; }
        = string.Empty;

        [Required(ErrorMessage = "Last Name is required")]
        [DataType(DataType.Text, ErrorMessage = "Please enter the correct last name")]
        public string LastName { get; set; }
        = string.Empty;

        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;

    }
}
