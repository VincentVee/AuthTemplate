﻿using InnovateRealEstate.Core.Models;

namespace InnovateRealEstate.Core.Responses;

public record PropertyResponse(
    string message = "",
    bool success = false, 
    string queue = "",
    List<Property>? properties = default,
    Property? property = default
    );
