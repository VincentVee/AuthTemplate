﻿namespace InnovateRealEstate.Core.Responses
{
    public record FileResponse(string? filePath = "", bool success = false, string message = "", string queue = "");

}
