﻿namespace InnovateRealEstate.Core.Responses
{
    public record AuthResponse<T>(
        string message = "", int code = 0, string token = "", string queue = "",List<T?> Data = null
        );
}
