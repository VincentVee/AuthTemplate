﻿using InnovateRealEstate.Core.DTOs;
using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;
using Microsoft.AspNetCore.Identity;


namespace InnovateRealEstate.Core.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponse<string>> Register(Register request);
        Task<AuthResponse<string>> Login(LoginUser request);
        Task<AuthResponse<string>> ChangePassword(ChangePasswordRequest model, string id);
        Task<AuthResponse<IdentityRole>> GetRoles();
        Task<AuthResponse<string>> ConfirmEmail(EmailAddressConfirmation model);
        Task<FileResponse> UpdateProfilePicture(UpdateProfileDto profileDto);
        Task<string> GetProfilePicture(string UserId);

    }
}
