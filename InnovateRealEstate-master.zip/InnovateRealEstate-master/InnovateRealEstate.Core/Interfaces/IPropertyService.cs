﻿using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;

namespace InnovateRealEstate.Core.Interfaces;

public interface IPropertyService
{
    Task<PropertyResponse> CreateProperty(Property property);
    Task<PropertyResponse> UpdateProperty(Property property);
    Task<PropertyResponse> DeleteProperty(Property property);
    Task<PropertyResponse> GetProperty(Property property);
    Task<PropertyResponse> GetAllProperties();

}
