﻿using InnovateRealEstate.Core.Responses;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;

namespace InnovateRealEstate.Core.Interfaces
{
    public interface IFileService
    {
        Task<FileResponse> SaveFilesAsync(IFormFile file, string imageType);

    }
}
