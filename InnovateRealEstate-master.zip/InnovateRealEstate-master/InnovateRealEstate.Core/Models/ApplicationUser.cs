﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace InnovateRealEstate.Core.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string? ProfilePicUrl { get; set; } = string.Empty;
        public string PhoneNumber {  get; set; }
    }
}
