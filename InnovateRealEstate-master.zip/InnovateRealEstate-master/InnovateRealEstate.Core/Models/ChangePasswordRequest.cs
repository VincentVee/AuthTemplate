﻿using System.ComponentModel.DataAnnotations;

namespace InnovateRealEstate.Core.Models
{
    public class ChangePasswordRequest
    {

        [Required(ErrorMessage = "Current Password is required!")]
        [DataType(DataType.Password)]
        public string CurrentPassword { get; set; }

        [Required(ErrorMessage = "New Password is required!")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "New Password Confirmation is required!")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "New Password and New Password Confirmation do not match")]
        public string ConfirmNewPassword { get; set; }
    }
}
