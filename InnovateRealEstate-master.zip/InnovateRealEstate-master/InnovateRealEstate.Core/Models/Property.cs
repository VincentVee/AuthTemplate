﻿using System.ComponentModel.DataAnnotations.Schema;

using InnovateRealEstate.Core.Helpers;

namespace InnovateRealEstate.Core.Models;

[Table("Property", Schema = "domain")]
public class Property
{
    public Guid Id { get; set; } = SequentialGuidHelper.NewSequentialGuid();
    public string Name { get; set; }
    public string Description { get; set; }
    public string Type { get; set; }
    public string Location { get; set; }
    public string Size { get; set; }
    public int NoOfRooms { get; set; }
    public string UserId { get; set;}

}
