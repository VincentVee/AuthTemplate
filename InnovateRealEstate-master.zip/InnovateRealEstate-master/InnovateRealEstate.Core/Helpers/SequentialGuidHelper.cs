﻿namespace InnovateRealEstate.Core.Helpers;

public static class SequentialGuidHelper
{
    public static Guid NewSequentialGuid()
    {
        var guidBytes = Guid.NewGuid().ToByteArray();
        var timestamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);

        // Combine timestamp with GUID
        Array.Copy(timestamp, 0, guidBytes, guidBytes.Length - timestamp.Length, timestamp.Length);

        return new Guid(guidBytes);
    }
}
