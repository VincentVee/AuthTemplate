﻿using InnovateRealEstate.Core.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Identity;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using InnovateRealEstate.Core.DTOs;
using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;
using System.Security.Policy;

namespace InnovateRealEstate.Services.Repositories
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _config;
        

        public EmailService(IConfiguration emailSettings)
        {
            _config = emailSettings;
  
        }

        public async Task SendEmailAsync(string toEmail, string subject, string message)
        {
            try
            {
                var email = new MimeMessage();
                email.From.Add(new MailboxAddress(_config["EmailSettings:FromName"], _config["EmailSettings:FromEmail"]));
                email.To.Add(new MailboxAddress("Real Estate Support", toEmail));
                email.Subject = subject;
                email.Body = new TextPart("html") { Text = message };

                using var client = new SmtpClient();
                await client.ConnectAsync(_config["EmailSettings:Host"], Convert.ToInt32(_config["EmailSettings:Port"]), false);
                await client.AuthenticateAsync(_config["EmailSettings:Username"], _config["EmailSettings:Password"]);
                await client.SendAsync(email);
                await client.DisconnectAsync(true);
            }
            catch (Exception)
            {

                throw;
            }
            
        }

    }
}
