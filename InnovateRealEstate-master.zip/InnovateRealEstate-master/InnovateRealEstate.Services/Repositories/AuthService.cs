﻿using InnovateRealEstate.Core.DTOs;
using InnovateRealEstate.Core.Interfaces;
using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace InnovateRealEstate.Services.Repositories
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _config;
        public AuthService(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration config)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _config = config;
        }


        public async Task<AuthResponse<string>> Register(Register request)
        {
            try
            {
                
                var user = new ApplicationUser
                {
                    UserName = request.UserName,
                    Email = request.Email,
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    PhoneNumber = request.PhoneNumber
                };
                var existingUser = await _userManager.FindByNameAsync(user.UserName);
                if (existingUser != null)
                {
                    return new AuthResponse<string>(
                        message: "The username you entered already exists, try a different one",
                        code: 403,
                        queue: "Registrater"
                        );
                }
                var existingUserEmail = await _userManager.FindByEmailAsync(request.Email);
                if (existingUserEmail != null)
                {
                    return new AuthResponse<string>(
                        message: "The email address you entered already exists, try a different one",
                        code: 403,
                        queue: "Registrater"
                        );
                }

                var result = await _userManager.CreateAsync(user, request.Password);
                var error = String.Empty;
                if (!result.Succeeded)
                {
                    foreach (var err in result.Errors)
                    {
                        error += err.Description;
                    }
                    return new AuthResponse<string>(
                        message: $"An error has occured: {error}",
                        code: 500, queue: "Register");

                }

                if (!await _roleManager.RoleExistsAsync(request.Role))
                    return new AuthResponse<string>(
                        message: "The role you supplied is invalid",
                        code: 500, queue: "Register");

                await _userManager.AddToRoleAsync(user, request.Role);

                return new AuthResponse<string>(
                        message: "User registered successfully!.", 
                        code: 201, queue: "Register");
            }
            catch (Exception ex)
            {

                return new AuthResponse<string>(message: $"An error occured, {ex.Message}", queue: "Register");
            }
            
        }

        public async Task<AuthResponse<string>> Login(LoginUser request)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(request.UserName);
                if (user == null || !await _userManager.CheckPasswordAsync(user, request.Password))
                    return new AuthResponse<string>(
                            message: "The credentials you entered are not valid!",
                            code: 500, queue: "Login");
                var checkEmailConfirmed = await _userManager.IsEmailConfirmedAsync(user);

                if (!checkEmailConfirmed)
                {
                    return new AuthResponse<string>(
                            message: "Please confirm your email before you can login!",
                            code: 203, queue: "Login");
                }
                var roles = await _userManager.GetRolesAsync(user);

                var token = GenerateJwtToken(user, roles); //JWT generation
                return new AuthResponse<string>(
                            message: "Logic success!", code: 200, token: token, queue: "Login");
            }
            catch (Exception ex)
            {

                return new AuthResponse<string>(
                        message: $"An error occured, {ex.Message}", code: 500, queue:"Login");
            }
            
        }

        private string GenerateJwtToken(ApplicationUser user, IList<string> roles)
        {
            try
            {
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.UserName!),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim("FirstName", user.FirstName!),
                new Claim("LastName", user.LastName!),
                new Claim(ClaimTypes.Email, user.Email!),
                new Claim(ClaimTypes.Name, user.UserName!),
                new Claim("PhoneNumber", user.PhoneNumber!)
            };

                // Add roles as claims
                claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

                var token = new JwtSecurityToken(
                    issuer: _config["Jwt:Issuer"],
                    audience: _config["Jwt:Audience"],
                    claims: claims,
                    expires: DateTime.Now.AddHours(1),
                    signingCredentials: creds
                );

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public async Task<AuthResponse<string>> ChangePassword(ChangePasswordRequest model, string id)
        {
            try
            {
                // Get the logged-in user
                var user = await _userManager.FindByIdAsync(id);

                if (user == null)
                {
                    return new AuthResponse<string>(message: $"The user details you supplied did not match any record", code: 204, queue: "ChangePassword");
                }
                // Change password
                var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
                var error = String.Empty;
                if (!result.Succeeded)
                {
                    foreach (var err in result.Errors)
                    {
                        error = error + err.Description;
                    } 
                    return new AuthResponse<string>(
                        message: $"An error has occured: {error}", 
                        code: 500, queue: "ChangePassword");

                }

                return new AuthResponse<string>(
                    message: "Password changed successfully.", 
                    code: 200, queue: "ChangePassword");
            }
            catch (Exception ex)
            {
                return new AuthResponse<string>(
                    message: $"An error has occured: {ex.Message}", 
                    code: 500, queue: "ChangePassword");
            }
            
        }

        public async Task<AuthResponse<IdentityRole>> GetRoles()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            if(roles != null)
            {
                return new AuthResponse<IdentityRole>(
                    message: "Roles retrieved successfully.",
                    code: 200, queue: "GetRoles",Data: roles!);
            }
            return new AuthResponse<IdentityRole>(
                    message: "No role(s) were found in the system",
                    code: 401, queue: "GetRoles");

        }

        public async Task<AuthResponse<string>> ConfirmEmail(EmailAddressConfirmation model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);

            if(user == null)
            {
                return new AuthResponse<string>(
                    message: "The email address you provided does not exist.",
                    code: 404, queue: "ConfirmEmail");
            }

            var checkUserToken = await _userManager.ConfirmEmailAsync(user, model.Token);

            if(!checkUserToken.Succeeded) return new AuthResponse<string>(
                    message: "The token is invalid",
                    code: 404, queue: "ConfirmEmail");

            return new AuthResponse<string>(
                message: "Your email has been confirmed successfully!",
                code: 200,
                queue: "ConfirmEmail"
                );
        }

        public async Task<FileResponse> UpdateProfilePicture(UpdateProfileDto profileDto)
        {
            var user = await _userManager.FindByIdAsync(profileDto.UsertId);

            if(user != null)
            {
                user.UserName = profileDto.UserName;
                user.FirstName = profileDto.FirstName;
                user.LastName = profileDto.LastName;
                user.Email = profileDto.Email;
                user.PhoneNumber = profileDto.PhoneNumber;
                user.ProfilePicUrl = profileDto.ProfilePicUrl;

                var result = await _userManager.UpdateAsync(user);
                if(result.Succeeded)
                {
                    return new FileResponse(
                        message: $"Profile updated successfully!",
                        success: true, queue: "UpdateProfilePicture");
                }

            }
            
            return new FileResponse(
                    message: $"The user {profileDto.UserName} does not exist.",
                    success: false, queue: "UpdateProfilePicture");

        }

        public async Task<string> GetProfilePicture(string UserId)
        {
            var user = await _userManager.FindByIdAsync(UserId);

            if(user != null)
            {
                return user.ProfilePicUrl!;
            }
            return "";

        }
    }
}
