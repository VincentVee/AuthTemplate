﻿using InnovateRealEstate.Core.Interfaces;
using InnovateRealEstate.Core.Responses;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using System.Net.Http;

namespace InnovateRealEstate.Services.Repositories
{
    public class FileService : IFileService
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        public FileService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<FileResponse> SaveFilesAsync(IFormFile file, string imageType)
        {
            // Validate file content type
            var supportedTypes = new[] { "image/jpeg", "image/png" }; // Supported MIME types
            if (!supportedTypes.Contains(file.ContentType))
            {
                return new FileResponse
                {
                    success = false,
                    message = "Unsupported file type."
                };
            }

            // Determine the correct extension based on MIME type
            var extension = file.ContentType switch
            {
                "image/jpeg" => ".jpg",
                "image/png" => ".png",
                _ => throw new InvalidOperationException("Unsupported file type.")
            };

            // Generate unique file name
            var uniqueFileName = $"{Guid.NewGuid()}{extension}";

            // Define save path
            var rootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
            var relativeDirectory = imageType == "Listing" ? "listings" : "profilePictures";
            var directoryPath = Path.Combine(rootPath, relativeDirectory);

            // Ensure directory exists
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            // Save the file
            var fullPath = Path.Combine(directoryPath, uniqueFileName);
            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // Construct the base URL dynamically
            var httpContext = _httpContextAccessor.HttpContext;
            var baseUrl = $"{httpContext.Request.Scheme}://{httpContext.Request.Host.Value}";

            // Return the full path as URL
            var relativePath = Path.Combine(relativeDirectory, uniqueFileName).Replace("\\", "/");
            var fullUrl = $"{baseUrl}/{relativePath}";

            return new FileResponse
            {
                success = true,
                filePath = fullUrl
            };
        }




    }
}
