﻿using InnovateRealEstate.Core.Interfaces;
using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;
using InnovateRealEstate.Data.Contexts;

using Microsoft.EntityFrameworkCore;

namespace InnovateRealEstate.Services.Repositories;

public class PropertyService : IPropertyService
{
    private readonly DataDbContext _context;

    public PropertyService(DataDbContext context)
    {
        _context = context;
    }
    public async Task<PropertyResponse> CreateProperty(Property property)
    {

        if (property == null) return new PropertyResponse(
            message: "Please make sure you enter all the required fields",
            success: false,
            queue: "PropertyService - CreateProperty"
            );

        var existingProperty = await _context.Properties.Where(v=> v.UserId == property.UserId).FirstOrDefaultAsync();

        if (existingProperty != null) 
            return new PropertyResponse(
                message: "You have already added this property",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        await _context.Properties.AddAsync(property);
        await _context.SaveChangesAsync();

        if (!_context.SaveChangesAsync().IsCompletedSuccessfully)
            return new PropertyResponse(
                message: "An error occured, could not add the property",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        return new PropertyResponse(
                message: "Property added successfully",
                success: true,
                queue: "PropertyService - CreateProperty"
                );

    }

    public async Task<PropertyResponse> DeleteProperty(Property property)
    {
        var propertyToRemove = await _context.Properties.Where(v=> v.Id == property.Id).FirstOrDefaultAsync();

        if(propertyToRemove == null) 
            return new PropertyResponse(
                message: "The property you want to delete does not exist",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        _context.Remove(propertyToRemove);
        await _context.SaveChangesAsync();

        if (!_context.SaveChangesAsync().IsCompletedSuccessfully)
            return new PropertyResponse(
                message: "An error occured, could not delete the property",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        return new PropertyResponse(
                message: "Property deleted successfully",
                success: true,
                queue: "PropertyService - CreateProperty"
                );
    }

    public async Task<PropertyResponse> GetAllProperties()
    {
        var properties = await _context.Properties.ToListAsync();
        if (!properties.Any()) 
            return new PropertyResponse (
                message: "There are no properties available",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        return new PropertyResponse (
                message: "There are no properties available",
                success: false,
                queue: "PropertyService - CreateProperty",
                properties: properties
                );
    }

    public async Task<PropertyResponse> GetProperty(Property property)
    {
        var propertyToGet = await _context.Properties.Where(v => v.Id == property.Id).FirstOrDefaultAsync();

        if (propertyToGet == null)
            return new PropertyResponse(
                message: "The property you want to view does not exist",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        return new PropertyResponse(
                message: "Property retrieved successfully",
                success: true,
                queue: "PropertyService - CreateProperty",
                property: propertyToGet
                );
    }

    public async Task<PropertyResponse> UpdateProperty(Property property)
    {
        var propertyToUpdate = await _context.Properties.Where(v => v.Id == property.Id).FirstOrDefaultAsync();

        if (propertyToUpdate == null)
            return new PropertyResponse(
                message: "The property you want to update does not exist",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        _context.Properties.Update(propertyToUpdate);
        await _context.SaveChangesAsync();

        if (!_context.SaveChangesAsync().IsCompletedSuccessfully)
            return new PropertyResponse(
                message: "An error occured, could not update the property",
                success: false,
                queue: "PropertyService - CreateProperty"
                );

        return new PropertyResponse(
                message: "Property updated successfully",
                success: true,
                queue: "PropertyService - CreateProperty"
                );
    }
}
