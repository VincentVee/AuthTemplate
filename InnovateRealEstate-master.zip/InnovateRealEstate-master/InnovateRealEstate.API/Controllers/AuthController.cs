﻿using FluentEmail.Core;
using InnovateRealEstate.Core.DTOs;
using InnovateRealEstate.Core.Interfaces;
using InnovateRealEstate.Core.Models;
using InnovateRealEstate.Core.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;

namespace InnovateRealEstate.API.Controllers
{
    [AllowAnonymous]
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
     
        private readonly IAuthService _authService;
        private readonly IEmailService _emailService;
        private readonly IFileService _fileService;
        private readonly UserManager<ApplicationUser> _userManager;

        public AuthController(IAuthService authService, IEmailService emailService, UserManager<ApplicationUser> userManager, IFileService fileService)
        {
            _authService = authService;
            _emailService = emailService;
            _userManager = userManager;
            _fileService = fileService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody]Register request)
        {
            if (ModelState.IsValid)
            {
                    var result = await _authService.Register(request);
                    if (result.code == 201)
                    {
                        var user = await _userManager.FindByEmailAsync(request.Email);

                        var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
                        var param = new Dictionary<string, string>
                        {
                            { "token", token},
                            {"email",user!.Email!}

                        };
                    // Create the reset link
                    request.ClientUrl = "https://localhost:7120/email-confirmation";
                    var callback = QueryHelpers.AddQueryString(request.ClientUrl, param!);

                    // Send reset link via email
                    var subject = "Email Confirmation";
                    var message = $"Please confirm your email by clicking <a href='{callback}'>here</a>";

                    await _emailService.SendEmailAsync(user.Email!, subject, message);
                    return Ok(result);
                }
                return BadRequest(result);
            }
            return BadRequest("The information you supplied is not complete");
          
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginUser request)
        {
            if (ModelState.IsValid)
            {
                var result = await _authService.Login(request);
                if (result.code == 200)
                {
                    return Ok(result);
                }
                return BadRequest(result);
            }
            return BadRequest();
        }

        [HttpPost("change-password/{id}")]
       
        public async Task<IActionResult> ChangePassword(string id,[FromBody] ChangePasswordRequest model)
        {
            if (ModelState.IsValid)
            {
                var result = await _authService.ChangePassword(model, id);

                if (result.code != 200)
                    return BadRequest(result);

                return Ok(result);
            }
             return BadRequest();
            
        }

        [HttpPost("forgot-password")]
        public async Task<ActionResult<AuthResponse<string>>> ForgotPassword([FromBody] ForgotPasswordRequest model)
        {
            //model.ClientUrl = "https://localhost:7120/reset-password";
            // Find the user by email
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
                return BadRequest(new AuthResponse<string>(message: "Email not found.",code: 404, queue: "ForgotPassword"));

            // Generate password reset token
            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
            var param = new Dictionary<string, string>
            {
                { "token", token},
                {"email",user.Email!}

            };
            // Create the reset link
            //var resetLink = $"https://localhost:7120/reset-password?token={token}&email={user.Email}";//Url.RouteUrl("reset-password", new { token, email = user.Email }, Request.Scheme);
            var callback = QueryHelpers.AddQueryString(model.ClientUrl, param!);
            // Send reset link via email
            var subject = "Password Reset Request";
            var message = $"Please reset your password by clicking <a href='{callback}'>here</a>";

            await _emailService.SendEmailAsync(user.Email!, subject, message);

            return Ok(new AuthResponse<string>(message: "Reset link has been sent to your email.", code: 200, queue: "ForgotPassword"));
        }

        [HttpPost("reset-password")]
        [IgnoreAntiforgeryToken]
        public async Task<ActionResult<AuthResponse<string>>> ResetPassword(ResetPasswordRequest model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
                return NotFound(new { message = "User not found." });

            var result = await _userManager.ResetPasswordAsync(user,model.Token, model.NewPassword);

            var error = "";
            if (!result.Succeeded)
            {
                foreach (var err in result.Errors)
                {
                    error += err.Description;
                }
                return BadRequest(new AuthResponse<string>(message: $"An error has occured: {error}"));
            }

            return Ok(new AuthResponse<string>(message: "Password reset successfully."));
        }

        [HttpGet("get-roles")]
        public async Task<ActionResult<AuthResponse<IdentityRole>>> GetRoles()
        {
            var result = await _authService.GetRoles();

            if(result.code == 200)
            {
                return Ok(result);
            }
           
                return BadRequest(result);

        }
        [AllowAnonymous]
        [HttpPost("email-confirmation")]
        public async Task<ActionResult<AuthResponse<IdentityRole>>> ConfirmEmail([FromBody] EmailAddressConfirmation model)
        {
            if(ModelState.IsValid)
            {
                    var result = await _authService.ConfirmEmail(model);

                    if (result.code == 200)
                    {
                        return Ok(result);
                    }

                    return BadRequest(result);
            }
            return BadRequest("The information is not valid. Please try again");
            

        }


        [HttpPost("Upload-Profile-Picture/{imageType}")]
        [Consumes("multipart/form-data")]
        public async Task<ActionResult<FileResponse>> UploadProfilePicture(string imageType, IFormFile files)
        {

            var result = await _fileService.SaveFilesAsync(files, imageType);

            if (result.success == true)
            {
                return Ok(result);
            }

            return BadRequest();

        }

        [HttpPost("update-Profile-Picture")]
        public async Task<ActionResult<FileResponse>> UpdateProfilePicture(UpdateProfileDto profileDto)
        {

            var result = await _authService.UpdateProfilePicture(profileDto);

            if (result.success == true)
            {
                return Ok(result);
            }

            return BadRequest();

        }

        [HttpGet("get-Profile-Picture/{userId}")]
        public async Task<ActionResult<FileResponse>> GetProfilePicture(string userId)
        {

            var result = await _authService.GetProfilePicture(userId);

            if (result != null)
            {
                return Ok(result);
            }

            return BadRequest();

        }

    }
}
