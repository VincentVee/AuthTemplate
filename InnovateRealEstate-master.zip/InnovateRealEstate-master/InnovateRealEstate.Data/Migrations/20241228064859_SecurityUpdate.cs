﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace InnovateRealEstate.Data.Migrations
{
    /// <inheritdoc />
    public partial class SecurityUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4fa3885e-c36d-43d0-9031-a3641cfb823f");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a383299a-4fdb-4ce9-a8bf-9752c075ec77");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "c0b850fb-ce29-4da4-bca1-bc90f4c3fda5");

            migrationBuilder.AlterColumn<string>(
                name: "ProfilePicUrl",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "0206a2e9-850e-4fef-934a-6710ea6c8dd2", null, "Tenant", "TENANT" },
                    { "6881f502-423b-494a-9a80-112eb77a79e7", null, "Admin", "ADMIN" },
                    { "78d0abdf-eca6-49b9-ae16-ed8b60966f47", null, "Landlord", "LANDLORD" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "0206a2e9-850e-4fef-934a-6710ea6c8dd2");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "6881f502-423b-494a-9a80-112eb77a79e7");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "78d0abdf-eca6-49b9-ae16-ed8b60966f47");

            migrationBuilder.AlterColumn<string>(
                name: "ProfilePicUrl",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "4fa3885e-c36d-43d0-9031-a3641cfb823f", null, "Tenant", "TENANT" },
                    { "a383299a-4fdb-4ce9-a8bf-9752c075ec77", null, "Admin", "ADMIN" },
                    { "c0b850fb-ce29-4da4-bca1-bc90f4c3fda5", null, "Landlord", "LANDLORD" }
                });
        }
    }
}
