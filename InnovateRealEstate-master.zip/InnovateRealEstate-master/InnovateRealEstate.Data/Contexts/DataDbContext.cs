﻿using InnovateRealEstate.Core.Models;
using Microsoft.EntityFrameworkCore;
namespace InnovateRealEstate.Data.Contexts;

public class DataDbContext: DbContext
{
    public DataDbContext(DbContextOptions<DataDbContext>options): base(options)
    {
            
    }

    public DbSet<Property> Properties { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Property>(entity =>
        {
            entity.HasKey(e => e.Id); // Explicitly set the primary key
            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd(); // Ensure the value is generated on insertion
        });
    }
}
