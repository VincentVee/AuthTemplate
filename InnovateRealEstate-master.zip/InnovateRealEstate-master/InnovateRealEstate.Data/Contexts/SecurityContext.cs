﻿using InnovateRealEstate.Core.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InnovateRealEstate.Data.Contexts
{
    public class SecurityContext : IdentityDbContext<ApplicationUser, IdentityRole, string>
    {
        public SecurityContext(DbContextOptions<SecurityContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Seed Roles
            builder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = Guid.NewGuid().ToString(), Name = "Admin", NormalizedName = "ADMIN" },
                new IdentityRole { Id = Guid.NewGuid().ToString(), Name = "Tenant", NormalizedName = "TENANT" },
                new IdentityRole { Id = Guid.NewGuid().ToString(), Name = "Landlord", NormalizedName = "LANDLORD" }
            );
            builder.Ignore<System.ComponentModel.DataAnnotations.DisplayFormatAttribute>();
        }
    }
}
